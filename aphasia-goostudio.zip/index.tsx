/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI, GenerateContentResponse } from '@google/genai';

// --- TYPE DEFINITIONS ---
interface Suggestion {
  phrase: string;
  keyword: string;
}

// --- BROWSER API SETUP ---
const SpeechRecognitionImpl = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
const synthesis = window.speechSynthesis;

// --- STATE MANAGEMENT ---
let ai: GoogleGenAI | null = null;
let recognition: SpeechRecognition | null = null;
let isListening = false;
let apiKey: string | null = null;

// --- DOM ELEMENTS ---
const apiKeyModal = document.getElementById('apiKeyModal') as HTMLDivElement;
const apiKeyInput = document.getElementById('apiKeyInput') as HTMLInputElement;
const saveApiKeyButton = document.getElementById('saveApiKeyButton') as HTMLButtonElement;
const appContainer = document.getElementById('app') as HTMLDivElement;
const listenButton = document.getElementById('listenButton') as HTMLButtonElement;
const statusDisplay = document.getElementById('status') as HTMLDivElement;
const suggestionsGrid = document.getElementById('suggestions') as HTMLDivElement;
const tabButtons = document.querySelectorAll('.tab-button');
const moduleContainers = document.querySelectorAll('.module');

// --- INITIALIZATION ---
window.addEventListener('load', () => {
  if (!SpeechRecognitionImpl) {
    showError('Seu navegador não suporta a API de Reconhecimento de Fala. Tente usar o Chrome.');
    listenButton.disabled = true;
  }
  
  setupApiKey();
  setupEventListeners();
});

function setupApiKey() {
  apiKey = localStorage.getItem('geminiApiKey');
  if (apiKey) {
    initializeAi(apiKey);
    apiKeyModal.setAttribute('hidden', 'true');
    appContainer.removeAttribute('hidden');
  } else {
    apiKeyModal.removeAttribute('hidden');
  }
}

function initializeAi(key: string) {
  try {
    ai = new GoogleGenAI({ apiKey: key });
    apiKey = key;
  } catch(e) {
    showError("Ocorreu um erro ao inicializar o Gemini. Verifique sua chave de API.");
    localStorage.removeItem('geminiApiKey');
    apiKey = null;
    ai = null;
    apiKeyModal.removeAttribute('hidden');
    appContainer.setAttribute('hidden', 'true');
  }
}

function setupEventListeners() {
  saveApiKeyButton.addEventListener('click', () => {
    const key = apiKeyInput.value.trim();
    if (key) {
      localStorage.setItem('geminiApiKey', key);
      initializeAi(key);
      if (ai) {
          apiKeyModal.setAttribute('hidden', 'true');
          appContainer.removeAttribute('hidden');
      }
    } else {
        alert("Por favor, insira uma chave de API válida.");
    }
  });

  listenButton.addEventListener('click', toggleListening);
  
  tabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const tabId = (button as HTMLElement).dataset.tab;
      if (!tabId || (button as HTMLButtonElement).disabled) return;

      tabButtons.forEach(btn => btn.classList.remove('active'));
      button.classList.add('active');

      moduleContainers.forEach(container => {
        if (container.id === tabId) {
          container.removeAttribute('hidden');
          (container as HTMLElement).classList.add('active');
        } else {
          container.setAttribute('hidden', 'true');
          (container as HTMLElement).classList.remove('active');
        }
      });
    });
  });
}


// --- SPEECH RECOGNITION ---
function toggleListening() {
  if (!SpeechRecognitionImpl) return;

  if (isListening) {
    recognition?.stop();
    return;
  }

  isListening = true;
  listenButton.classList.add('listening');
  listenButton.disabled = true;
  listenButton.querySelector('span')!.textContent = 'Ouvindo...';
  statusDisplay.textContent = 'Por favor, comece a falar.';
  suggestionsGrid.innerHTML = '';
  
  recognition = new SpeechRecognitionImpl();
  recognition.lang = 'pt-BR';
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;

  recognition.start();

  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    statusDisplay.textContent = `Você disse: "${transcript}"`;
    getSuggestions(transcript);
  };

  recognition.onspeechend = () => {
    recognition?.stop();
  };
  
  recognition.onend = () => {
    isListening = false;
    listenButton.classList.remove('listening');
    listenButton.disabled = false;
    listenButton.querySelector('span')!.textContent = 'Ouvir';
  };

  recognition.onerror = (event) => {
    showError(`Erro no reconhecimento de fala: ${event.error}`);
    recognition?.stop();
  };
}


// --- GEMINI API INTERACTION ---
async function getSuggestions(text: string) {
  if (!ai) {
    showError("A API do Gemini não foi inicializada. Verifique sua chave.");
    return;
  }

  statusDisplay.textContent = 'Pensando em sugestões...';
  suggestionsGrid.innerHTML = '<div class="loading-spinner"></div>';
  listenButton.disabled = true;

  try {
    const prompt = `Uma pessoa com dificuldade de fala disse: "${text}". Ela parece estar travada.
    Sugira três frases curtas e simples em português do Brasil que ela possa estar tentando dizer.
    Para cada frase, forneça uma única palavra-chave simples (em inglês) para encontrar uma imagem representativa.
    Responda em formato JSON com uma lista de objetos, cada um com as chaves "phrase" e "keyword". Exemplo: [{"phrase": "Eu estou com sede.", "keyword": "water"}]`;

    const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash-preview-04-17',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
        }
    });

    let jsonStr = response.text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }
    
    const suggestions: Suggestion[] = JSON.parse(jsonStr);
    renderSuggestions(suggestions);

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    showError("Não foi possível obter sugestões. Tente novamente.");
  } finally {
    listenButton.disabled = false;
  }
}

// --- UI RENDERING ---
function renderSuggestions(suggestions: Suggestion[]) {
  suggestionsGrid.innerHTML = '';
  if (!suggestions || suggestions.length === 0) {
    statusDisplay.textContent = 'Não consegui encontrar sugestões. Tente ser mais específico.';
    return;
  }
  
  statusDisplay.textContent = 'Aqui estão algumas sugestões. Toque em uma para falar.';

  suggestions.forEach(suggestion => {
    const card = document.createElement('div');
    card.className = 'suggestion-card';
    card.setAttribute('role', 'button');
    card.tabIndex = 0;

    const imageUrl = `https://source.unsplash.com/300x180/?${encodeURIComponent(suggestion.keyword)}`;
    const image = document.createElement('img');
    image.src = imageUrl;
    image.alt = suggestion.keyword;
    
    const textDiv = document.createElement('div');
    textDiv.className = 'text';
    textDiv.textContent = suggestion.phrase;

    card.appendChild(image);
    card.appendChild(textDiv);

    card.addEventListener('click', () => speak(suggestion.phrase));
    card.addEventListener('keydown', (e) => {
        if(e.key === 'Enter' || e.key === ' ') {
            speak(suggestion.phrase);
        }
    });

    suggestionsGrid.appendChild(card);
  });
}

function speak(text: string) {
  if (synthesis.speaking) {
    synthesis.cancel();
  }
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'pt-BR';
  utterance.rate = 0.9;
  synthesis.speak(utterance);
}

function showError(message: string) {
    statusDisplay.textContent = message;
    statusDisplay.style.color = "var(--error-color)";
    setTimeout(() => {
        statusDisplay.textContent = '';
        statusDisplay.style.color = '';
    }, 5000);
}
